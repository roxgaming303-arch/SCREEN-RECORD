package com.example.cleanscreenrecorder

import android.app.*
import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.os.Environment
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.File

class RecordingService : Service() {
    companion object {
        const val ACTION_START = "com.example.cleanscreenrecorder.START"
        const val ACTION_STOP = "com.example.cleanscreenrecorder.STOP"
        const val ACTION_PAUSE = "com.example.cleanscreenrecorder.PAUSE"
        const val ACTION_RESUME = "com.example.cleanscreenrecorder.RESUME"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "data"
        const val EXTRA_HEIGHT = "height"
        const val EXTRA_FPS = "fps"
        const val EXTRA_BITRATE = "bitrate"
        const val EXTRA_MIC = "mic"
        private const val CHANNEL_ID = "screen_recording"
        private const val NOTIFICATION_ID = 7
    }

    private var projection: MediaProjection? = null
    private var recorder: MediaRecorder? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var isRecording = false
    private var isPaused = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopRecording()
            ACTION_PAUSE -> pauseRecording()
            ACTION_RESUME -> resumeRecording()
            ACTION_START -> {
                val code = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val data = if (Build.VERSION.SDK_INT >= 33)
                    intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
                else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_DATA) as? Intent
                if (data != null) startRecording(code, data, intent)
            }
        }
        return START_NOT_STICKY
    }

    private fun notification(): Notification {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26)
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Screen recording", NotificationManager.IMPORTANCE_LOW))
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID)
                      else @Suppress("DEPRECATION") Notification.Builder(this)
        return builder.setContentTitle("Clean Screen Recorder")
            .setContentText("Screen recording is active")
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setOngoing(true).build()
    }

    private fun startRecording(resultCode: Int, data: Intent, config: Intent) {
        try {
            startForeground(NOTIFICATION_ID, notification())
            val pm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = pm.getMediaProjection(resultCode, data)

            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
            val screenW = metrics.widthPixels
            val screenH = metrics.heightPixels
            val requestedHeight = config.getIntExtra(EXTRA_HEIGHT, 0)
            val outH = if (requestedHeight == 0) screenH else minOf(requestedHeight, screenH)
            val outW = ((screenW.toFloat() * outH / screenH).toInt()).let { it - (it % 2) }
            val density = metrics.densityDpi
            val frameRate = config.getIntExtra(EXTRA_FPS, 30)
            val bitRate = config.getIntExtra(EXTRA_BITRATE, 8_000_000)
            val useMic = config.getBooleanExtra(EXTRA_MIC, true)

            val dir = File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "CleanRecorder")
            if (!dir.exists()) dir.mkdirs()
            val output = File(dir, "screen_${System.currentTimeMillis()}.mp4")

            recorder = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this)
                       else @Suppress("DEPRECATION") MediaRecorder()
            recorder?.apply {
                if (useMic) setAudioSource(MediaRecorder.AudioSource.MIC)
                setVideoSource(MediaRecorder.VideoSource.SURFACE)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                if (useMic) {
                    setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                    setAudioEncodingBitRate(128_000)
                    setAudioSamplingRate(44_100)
                }
                setVideoEncoder(MediaRecorder.VideoEncoder.H264)
                setVideoSize(outW, outH)
                setVideoFrameRate(frameRate)
                setVideoEncodingBitRate(bitRate)
                setOutputFile(output.absolutePath)
                prepare()
            }
            virtualDisplay = projection?.createVirtualDisplay(
                "CleanScreenRecorder", outW, outH, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                recorder?.surface, null, null
            )
            recorder?.start()
            isRecording = true
            isPaused = false
        } catch (_: Exception) {
            stopRecording()
        }
    }

    private fun pauseRecording() {
        if (Build.VERSION.SDK_INT >= 24 && isRecording && !isPaused) {
            try { recorder?.pause(); isPaused = true } catch (_: Exception) {}
        }
    }

    private fun resumeRecording() {
        if (Build.VERSION.SDK_INT >= 24 && isRecording && isPaused) {
            try { recorder?.resume(); isPaused = false } catch (_: Exception) {}
        }
    }

    private fun stopRecording() {
        if (isRecording) try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.reset(); recorder?.release() } catch (_: Exception) {}
        recorder = null
        virtualDisplay?.release(); virtualDisplay = null
        projection?.stop(); projection = null
        isRecording = false; isPaused = false
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE)
        else @Suppress("DEPRECATION") stopForeground(true)
        stopSelf()
    }

    override fun onDestroy() {
        stopRecording()
        super.onDestroy()
    }
}
