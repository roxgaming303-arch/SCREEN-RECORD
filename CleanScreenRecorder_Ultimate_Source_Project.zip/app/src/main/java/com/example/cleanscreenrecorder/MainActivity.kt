package com.example.cleanscreenrecorder

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.*
import android.view.Gravity
import android.graphics.Color
import android.content.pm.PackageManager

class MainActivity : Activity() {
    private val requestCapture = 410
    private val requestMic = 411
    private lateinit var projectionManager: MediaProjectionManager
    private lateinit var resolution: Spinner
    private lateinit var fps: Spinner
    private lateinit var bitrate: Spinner
    private lateinit var mic: CheckBox

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.rgb(16, 24, 32))
        }
        fun label(s: String) = TextView(this).apply {
            text = s; textSize = 14f; setTextColor(Color.WHITE)
            setPadding(0, 12, 0, 5)
        }
        val title = TextView(this).apply {
            text = "CLEAN SCREEN RECORDER"
            textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(0, 10, 0, 10)
        }
        root.addView(title)
        val sub = TextView(this).apply {
            text = "Choose quality supported by your phone. No app watermark is added."
            textSize = 13f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
        }
        root.addView(sub)

        root.addView(label("Video resolution"))
        resolution = spinner(root, listOf("Device native", "480p", "720p HD", "1080p Full HD", "1440p 2K", "2160p 4K"))
        root.addView(label("Frame rate"))
        fps = spinner(root, listOf("15 FPS", "24 FPS", "30 FPS", "60 FPS"))
        root.addView(label("Video bitrate"))
        bitrate = spinner(root, listOf("4 Mbps", "8 Mbps", "12 Mbps", "20 Mbps", "40 Mbps"))
        mic = CheckBox(this).apply {
            text = "Record microphone audio"
            isChecked = true
            setTextColor(Color.WHITE)
        }
        root.addView(mic)

        val start = Button(this).apply {
            text = "START RECORDING"
            setOnClickListener {
                if (mic.isChecked && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), requestMic)
                } else requestScreenCapture()
            }
        }
        val pause = Button(this).apply {
            text = "PAUSE"
            setOnClickListener { sendAction(RecordingService.ACTION_PAUSE) }
        }
        val resume = Button(this).apply {
            text = "RESUME"
            setOnClickListener { sendAction(RecordingService.ACTION_RESUME) }
        }
        val stop = Button(this).apply {
            text = "STOP & SAVE"
            setOnClickListener { sendAction(RecordingService.ACTION_STOP) }
        }
        root.addView(start); root.addView(pause); root.addView(resume); root.addView(stop)

        val note = TextView(this).apply {
            text = "Important: 4K/60 FPS is available only when the device can capture and encode it. This build records microphone audio; internal app audio and YouTube live streaming are not implemented yet. Android's own capture indicator may appear."
            textSize = 12f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
            setPadding(0, 18, 0, 0)
        }
        root.addView(note)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun spinner(parent: LinearLayout, values: List<String>): Spinner {
        val s = Spinner(this)
        s.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, values)
        parent.addView(s)
        return s
    }

    private fun requestScreenCapture() {
        startActivityForResult(projectionManager.createScreenCaptureIntent(), requestCapture)
    }

    private fun sendAction(action: String) {
        startService(Intent(this, RecordingService::class.java).setAction(action))
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestMic) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) requestScreenCapture()
            else Toast.makeText(this, "Microphone permission denied.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated Android callback retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture && resultCode == RESULT_OK && data != null) {
            val sizes = arrayOf(0, 480, 720, 1080, 1440, 2160)
            val fpsValues = intArrayOf(15, 24, 30, 60)
            val bitrates = intArrayOf(4_000_000, 8_000_000, 12_000_000, 20_000_000, 40_000_000)
            val service = Intent(this, RecordingService::class.java).apply {
                action = RecordingService.ACTION_START
                putExtra(RecordingService.EXTRA_RESULT_CODE, resultCode)
                putExtra(RecordingService.EXTRA_DATA, data)
                putExtra(RecordingService.EXTRA_HEIGHT, sizes[resolution.selectedItemPosition])
                putExtra(RecordingService.EXTRA_FPS, fpsValues[fps.selectedItemPosition])
                putExtra(RecordingService.EXTRA_BITRATE, bitrates[bitrate.selectedItemPosition])
                putExtra(RecordingService.EXTRA_MIC, mic.isChecked)
            }
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
            Toast.makeText(this, "Recording requested", Toast.LENGTH_SHORT).show()
        }
    }
}
