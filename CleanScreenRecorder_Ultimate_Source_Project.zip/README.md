# Clean Screen Recorder – Android source project

This is an Android Studio / GitHub Actions source project, not a prebuilt APK.

## Implemented in this prototype
- Android MediaProjection screen capture
- MP4/H.264 recording
- Resolution selector: device native, 480p, 720p, 1080p, 1440p, 2160p (requested output height is capped to the phone's native screen height)
- 15/24/30/60 FPS selection
- Bitrate selection
- Optional microphone AAC audio
- Pause / resume / stop
- No app-added watermark, logo, intro, or outro

## Not implemented yet
- Internal app audio capture
- YouTube RTMP live streaming
- Floating controls / touch indicators / screenshot button
- Gallery browser, trimming, scheduling, auto quality and theme switch
These need additional Android components, permissions, device testing, and (for YouTube Live) secure stream-key handling. This project does not claim those features are working.

## Build from a phone (no PC)
1. Create a GitHub account and a new repository.
2. Upload the contents of this ZIP to the repository using GitHub's mobile website or app.
3. Open the repository's **Actions** tab.
4. Select **Build Android APK** and tap **Run workflow** (or push to `main`).
5. When the workflow finishes, open its run and download the artifact named `CleanScreenRecorder-debug-apk`.
6. Extract the artifact ZIP and install `app-debug.apk`. Android may ask you to allow installation from that source.

## Important technical limits
- A 4K option does not guarantee true 4K detail. This code caps output height to the physical screen height; a phone with a lower-resolution display cannot produce genuine 4K screen detail.
- 60 FPS depends on display refresh rate, encoder support, thermal limits, and app performance.
- Android may show its own screen-capture indicator and foreground notification. These are system UI, not a watermark embedded in the saved video.
- The output is saved in the app-specific Movies/CleanRecorder folder.
- MediaProjection permission must be approved for each recording session.
- Only record content you have permission to capture.
